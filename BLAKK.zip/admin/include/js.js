
function myRefresh() {
    location.reload();
}
