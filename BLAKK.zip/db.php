<?php

$conn = mysqli_connect('localhost', 'kagcoke', 'duncanNDEGWA32973945?', 'kagcoke_blakk');

if(!$conn){
    die("No connection: ".mysqli_connect_error());
}