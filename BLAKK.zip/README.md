# BLAKK
Database to verify user signup and payment
